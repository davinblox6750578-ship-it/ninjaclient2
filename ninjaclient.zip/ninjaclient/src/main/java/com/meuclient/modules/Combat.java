package com.meuclient.modules;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.util.Hand;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

/** Funcoes compartilhadas pelos modulos de combate. */
public final class Combat {
    private Combat() {}

    public static PlayerEntity nearestPlayer(MinecraftClient mc, double range) {
        return nearestPlayer(mc, range, false);
    }

    /** Se requireSight for true, ignora jogadores escondidos atras de blocos. */
    public static PlayerEntity nearestPlayer(MinecraftClient mc, double range, boolean requireSight) {
        PlayerEntity best = null;
        double bestDist = range;
        for (Entity e : mc.world.getEntities()) {
            if (!(e instanceof PlayerEntity p) || p == mc.player || !p.isAlive() || p.isSpectator()) continue;
            if (requireSight && !mc.player.canSee(p)) continue;
            double d = mc.player.distanceTo(p);
            if (d <= bestDist) {
                bestDist = d;
                best = p;
            }
        }
        return best;
    }

    public static boolean cooldownReady(MinecraftClient mc) {
        return mc.player.getAttackCooldownProgress(0.5f) >= 0.92f;
    }

    /** Ataca quando a barra de cooldown estiver pelo menos em `minProgress` (0.0 a 1.0). */
    public static boolean cooldownReady(MinecraftClient mc, float minProgress) {
        return mc.player.getAttackCooldownProgress(0.5f) >= minProgress;
    }

    public static void attack(MinecraftClient mc, Entity target) {
        mc.interactionManager.attackEntity(mc.player, target);
        mc.player.swingHand(Hand.MAIN_HAND);
    }

    /** Gira a camera ate o alvo (olhos), no maximo `maxStep` graus por tick. */
    public static void aimAt(MinecraftClient mc, Entity target, float maxStep) {
        aimAtPos(mc, target.getEyePos(), maxStep);
    }

    /** Gira a camera ate um ponto qualquer, no maximo `maxStep` graus por tick. */
    public static void aimAtPos(MinecraftClient mc, Vec3d to, float maxStep) {
        Vec3d from = mc.player.getEyePos();
        double dx = to.x - from.x, dy = to.y - from.y, dz = to.z - from.z;
        float yaw = (float) Math.toDegrees(Math.atan2(dz, dx)) - 90f;
        float pitch = (float) -Math.toDegrees(Math.atan2(dy, Math.sqrt(dx * dx + dz * dz)));

        float dYaw = MathHelper.wrapDegrees(yaw - mc.player.getYaw());
        float dPitch = pitch - mc.player.getPitch();
        mc.player.setYaw(mc.player.getYaw() + MathHelper.clamp(dYaw, -maxStep, maxStep));
        mc.player.setPitch(MathHelper.clamp(mc.player.getPitch() + MathHelper.clamp(dPitch, -maxStep, maxStep), -90f, 90f));
    }

    /**
     * Ataque com mira silenciosa: avisa o servidor que voce olhou para o alvo,
     * ataca e logo em seguida avisa a mira real de volta. A sua camera NAO se mexe.
     */
    public static void silentAttack(MinecraftClient mc, Entity target) {
        Vec3d from = mc.player.getEyePos();
        Vec3d to = target.getBoundingBox().getCenter();
        double dx = to.x - from.x, dy = to.y - from.y, dz = to.z - from.z;
        float yaw = (float) Math.toDegrees(Math.atan2(dz, dx)) - 90f;
        float pitch = (float) -Math.toDegrees(Math.atan2(dy, Math.sqrt(dx * dx + dz * dz)));

        var net = mc.getNetworkHandler();
        if (net == null) return;

        net.sendPacket(new PlayerMoveC2SPacket.LookAndOnGround(yaw, pitch,
                mc.player.isOnGround(), mc.player.horizontalCollision));
        attack(mc, target);
        net.sendPacket(new PlayerMoveC2SPacket.LookAndOnGround(mc.player.getYaw(), mc.player.getPitch(),
                mc.player.isOnGround(), mc.player.horizontalCollision));
    }
}
