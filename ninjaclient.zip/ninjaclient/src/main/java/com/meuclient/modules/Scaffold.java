package com.meuclient.modules;

import com.meuclient.Category;
import com.meuclient.Module;
import net.minecraft.block.Block;
import net.minecraft.block.BlockEntityProvider;
import net.minecraft.block.BlockState;
import net.minecraft.block.FallingBlock;
import net.minecraft.item.BlockItem;
import net.minecraft.item.ItemStack;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

/**
 * Scaffold: poe blocos automaticamente embaixo dos seus pes enquanto voce anda,
 * para voce atravessar vazio, rios ou lava sem parar. Usa os blocos da hotbar
 * (ignora blocos que caem, como areia, e blocos com inventario, como baus).
 *
 * Estilo de ponte legit (de jogador bom):
 *  - UMA linha de blocos, um por vez, so embaixo dos seus pes (nada de varias fileiras);
 *  - coloca so quando voce esta saindo da borda (1 tick a frente);
 *  - apoia primeiro no bloco de tras (o da ponte), depois nos lados;
 *  - 1 a 3 ticks aleatorios entre um bloco e outro.
 *
 * Como funciona a cada tick:
 *  1. calcula o bloco embaixo de voce (1 tick a frente pela velocidade);
 *  2. se esta vazio, escolhe o apoio: tras, lados, depois baixo;
 *  3. troca para um bloco da hotbar e coloca, com a mira silenciosa (a camera
 *     nao se mexe);
 *  4. ao desligar, devolve o slot que voce estava usando.
 */
public class Scaffold extends Module {
    private int originalSlot = -1;
    private int delay;
    private final java.util.Random random = new java.util.Random();

    public Scaffold() {
        super("Scaffold", Category.WORLD);
        enableToggleKey(-1); // sem tecla padrao: mapeie no menu
    }

    @Override
    public void onEnable() { originalSlot = -1; delay = 0; }

    @Override
    public void onDisable() {
        if (mc.player != null && originalSlot >= 0) {
            mc.player.getInventory().setSelectedSlot(originalSlot);
        }
        originalSlot = -1;
    }

    @Override
    public void onTick() {
        if (mc.currentScreen != null) return;
        if (delay > 0) { delay--; return; }

        int slot = findBlockSlot();
        if (slot == -1) return;

        // bloco logo abaixo dos pes, so 1 tick a frente: coloca no instante em que
        // voce esta saindo da borda, como um jogador bom fazendo ponte
        Vec3d vel = mc.player.getVelocity();
        BlockPos target = BlockPos.ofFloored(
                mc.player.getX() + vel.x,
                mc.player.getY() - 1.0,
                mc.player.getZ() + vel.z);
        if (!mc.world.getBlockState(target).isReplaceable()) return; // ja tem chao: nada a fazer

        // lado de onde voce vem: o bloco de tras e o apoio natural da ponte
        double hSpeed = Math.hypot(vel.x, vel.z);
        Direction moving = hSpeed > 0.03
                ? Direction.getFacing(vel.x, 0, vel.z)
                : mc.player.getHorizontalFacing();

        // ordem de apoio: bloco de tras, depois os dos lados, por ultimo o de baixo
        Direction[] order = {
                moving.getOpposite(),
                moving.rotateYClockwise(),
                moving.rotateYCounterclockwise(),
                moving,
                Direction.DOWN};

        for (Direction d : order) {
            BlockPos support = target.offset(d);
            BlockState st = mc.world.getBlockState(support);
            if (st.isAir() || st.isReplaceable()) continue;
            // face do apoio que aponta para o bloco novo
            place(target, d.getOpposite(), slot);
            // ritmo humano: 1 a 3 ticks entre blocos
            delay = 1 + random.nextInt(3);
            return; // exatamente UM bloco por vez, so em linha reta
        }
    }

    private void place(BlockPos target, Direction faceOfSupport, int slot) {
        BlockPos support = target.offset(faceOfSupport.getOpposite());
        Vec3d hit = Vec3d.ofCenter(support).add(new Vec3d(
                faceOfSupport.getOffsetX(), faceOfSupport.getOffsetY(), faceOfSupport.getOffsetZ()).multiply(0.5));

        if (originalSlot < 0) originalSlot = mc.player.getInventory().getSelectedSlot();
        if (mc.player.getInventory().getSelectedSlot() != slot) {
            mc.player.getInventory().setSelectedSlot(slot);
        }

        // mira silenciosa: olha para o ponto, coloca e devolve a mira real
        var net = mc.getNetworkHandler();
        if (net != null) {
            Vec3d eye = mc.player.getEyePos();
            double dx = hit.x - eye.x, dy = hit.y - eye.y, dz = hit.z - eye.z;
            float yaw = (float) Math.toDegrees(Math.atan2(dz, dx)) - 90f;
            float pitch = (float) -Math.toDegrees(Math.atan2(dy, Math.sqrt(dx * dx + dz * dz)));
            net.sendPacket(new PlayerMoveC2SPacket.LookAndOnGround(yaw, pitch,
                    mc.player.isOnGround(), mc.player.horizontalCollision));
        }

        mc.interactionManager.interactBlock(mc.player, Hand.MAIN_HAND,
                new BlockHitResult(hit, faceOfSupport, support, false));
        mc.player.swingHand(Hand.MAIN_HAND);

        if (net != null) {
            net.sendPacket(new PlayerMoveC2SPacket.LookAndOnGround(mc.player.getYaw(), mc.player.getPitch(),
                    mc.player.isOnGround(), mc.player.horizontalCollision));
        }
    }

    /** Primeiro bloco solido "comum" da hotbar (sem blocos que caem nem com inventario). */
    private int findBlockSlot() {
        for (int i = 0; i < 9; i++) {
            ItemStack stack = mc.player.getInventory().getStack(i);
            if (stack.isEmpty() || !(stack.getItem() instanceof BlockItem bi)) continue;
            Block block = bi.getBlock();
            if (block instanceof FallingBlock || block instanceof BlockEntityProvider) continue;
            if (!block.getDefaultState().isSolidBlock(mc.world, BlockPos.ORIGIN)) continue;
            return i;
        }
        return -1;
    }
}
