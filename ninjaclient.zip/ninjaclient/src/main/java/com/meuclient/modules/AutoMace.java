package com.meuclient.modules;

import com.meuclient.Category;
import com.meuclient.Module;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;

/**
 * Caindo de uma altura (fallDistance > 1.5, o minimo do smash no vanilla):
 * troca para a clava da hotbar, mira no jogador mais proximo e ataca UMA vez.
 *  - nao ataca se o alvo estiver bloqueando com escudo (espera ele abaixar);
 *  - so ataca com a barra de cooldown cheia;
 *  - no maximo 1 ataque por queda e um intervalo minimo entre ataques,
 *    para nao ficar clicando sem parar.
 */
public class AutoMace extends Module {
    private static final double REACH = 3.0;
    private static final int MIN_GAP_TICKS = 10; // intervalo minimo entre ataques

    private boolean attackedThisFall;
    private int gap;

    public AutoMace() {
        super("AutoMace", Category.COMBAT);
        enableToggleKey(-1); // sem tecla padrao: mapeie no menu
    }

    @Override
    public void onDisable() {
        attackedThisFall = false;
        gap = 0;
    }

    @Override
    public void onTick() {
        if (gap > 0) gap--;

        // pousou: libera um novo ataque na proxima queda
        if (mc.player.isOnGround()) {
            attackedThisFall = false;
            return;
        }
        if (attackedThisFall || gap > 0) return;
        if (mc.player.fallDistance <= 1.5) return;

        PlayerEntity target = Combat.nearestPlayer(mc, REACH);
        if (target == null) return;

        // escudo levantado: o smash seria bloqueado, entao espera ele abaixar
        if (target.isBlocking()) return;

        // troca para a clava se nao estiver com ela na mao
        if (!mc.player.getMainHandStack().isOf(Items.MACE)) {
            for (int i = 0; i < 9; i++) {
                if (mc.player.getInventory().getStack(i).isOf(Items.MACE)) {
                    mc.player.getInventory().setSelectedSlot(i);
                    return; // ataca no proximo tick, ja com a clava
                }
            }
            return; // sem clava na hotbar
        }

        // cooldown cheio: ataque com a barra incompleta perde o bonus do smash
        if (!Combat.cooldownReady(mc, 0.92f)) return; // barra cheia (92%)

        Combat.aimAt(mc, target, 180f);
        Combat.attack(mc, target);
        attackedThisFall = true;
        gap = MIN_GAP_TICKS;
    }
}
