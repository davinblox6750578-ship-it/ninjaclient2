package com.meuclient.modules;

import com.meuclient.Category;
import com.meuclient.Module;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

/**
 * KillAura: ataca o jogador mais proximo que estiver ao alcance e visivel.
 * Ataque simples (sem pacotes de rotacao falsos): o servidor vanilla so confere
 * a distancia ate a caixa do alvo, entao nao precisa mirar. Isso evita o
 * conflito com os pacotes de movimento normais, que travava/atrapalhava o ataque.
 */
public class KillAura extends Module {
    // barra de cooldown minima para atacar: 0.90 = 90% (use 0.80 para 80%)
    private static final float MIN_COOLDOWN = 0.90f;
    // alcance medido dos olhos ate a caixa do alvo (o do jogo e 3.0)
    private static final double REACH = 3.0;

    public KillAura() {
        super("KillAura", Category.COMBAT);
        enableToggleKey(-1); // sem tecla padrao: mapeie no menu
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null || mc.interactionManager == null) return;
        if (mc.currentScreen != null || !mc.player.isAlive()) return;
        if (!Combat.cooldownReady(mc, MIN_COOLDOWN)) return;

        PlayerEntity target = pickTarget();
        if (target == null) return;
        Combat.attack(mc, target);
    }

    /** Jogador vivo, visivel, mais perto, com a caixa dentro do alcance. */
    private PlayerEntity pickTarget() {
        Vec3d eye = mc.player.getEyePos();
        PlayerEntity best = null;
        double bestDist = Double.MAX_VALUE;
        for (Entity e : mc.world.getEntities()) {
            if (!(e instanceof PlayerEntity p) || p == mc.player) continue;
            if (!p.isAlive() || p.isSpectator() || p.isInvulnerable()) continue;
            if (!mc.player.canSee(p)) continue;
            double d = distanceToBox(eye, p.getBoundingBox());
            if (d <= REACH && d < bestDist) {
                bestDist = d;
                best = p;
            }
        }
        return best;
    }

    private static double distanceToBox(Vec3d p, Box b) {
        double x = Math.max(Math.max(b.minX - p.x, 0), p.x - b.maxX);
        double y = Math.max(Math.max(b.minY - p.y, 0), p.y - b.maxY);
        double z = Math.max(Math.max(b.minZ - p.z, 0), p.z - b.maxZ);
        return Math.sqrt(x * x + y * y + z * z);
    }
}
