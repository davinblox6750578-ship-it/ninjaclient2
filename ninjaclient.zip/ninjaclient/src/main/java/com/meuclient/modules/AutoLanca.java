package com.meuclient.modules;

import com.meuclient.Category;
import com.meuclient.Module;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.network.packet.c2s.play.UpdateSelectedSlotC2SPacket;
import net.minecraft.registry.Registries;
import org.lwjgl.glfw.GLFW;

/**
 * AutoLanca (Minecraft 1.21.11): lunge swap com UM aperto de tecla.
 *
 * Aperta a tecla uma vez e ele faz tudo sozinho, no mesmo tick:
 *   1. procura o jogador mais proximo (ate 4.5 blocos, visivel) - OPCIONAL:
 *      com alvo ele ataca o jogador; sem alvo lanca para onde voce esta olhando;
 *   2. vai para uma mao vazia da hotbar (a "mao de apoio");
 *   3. troca para a lanca (prefere a com Lunge) -> ataca -> volta para a mao vazia;
 *   4. depois de ~0,6 s devolve o slot que voce estava usando.
 * Sem mao vazia na hotbar, troca para a lanca, ataca e volta ao slot original.
 * A mira e silenciosa: a sua camera nao se mexe. (Bug de atributos MC-28289.)
 *
 * Ligue o modulo no menu. Clique no botao da tecla ao lado do nome, aperte a
 * tecla nova e ela fica mapeada. Esc cancela. Sem tecla padrao.
 */
public class AutoLanca extends Module {
    private static final int RETURN_DELAY_TICKS = 12; // tempo ate devolver o slot original

    private int key = -1; // sem tecla padrao: mapeie no menu
    private boolean binding;
    private boolean keyHeld;

    private int originalSlot = -1;
    private int returnTimer;

    public AutoLanca() { super("AutoLanca", Category.COMBAT); }

    /** Botao de tecla no menu: mostra a tecla atual; clique para mapear outra. */
    @Override
    public String bindLabel() {
        if (binding) return "...";
        return keyName(key);
    }

    @Override
    public boolean hasKey() { return true; }

    @Override
    public int getKey() { return key; }

    @Override
    public void setKey(int k) { key = k; }

    @Override
    public void onBindClick() { binding = true; }

    @Override
    public void onRightClick() { binding = true; }

    /** Captura a nova tecla mesmo com o modulo desligado. */
    @Override
    public void onBackgroundTick() {
        if (!binding) return;
        long window = mc.getWindow().getHandle();
        for (int k = GLFW.GLFW_KEY_SPACE; k <= GLFW.GLFW_KEY_LAST; k++) {
            if (k == GLFW.GLFW_KEY_RIGHT_ALT) continue; // tecla do menu
            if (GLFW.glfwGetKey(window, k) == GLFW.GLFW_PRESS) {
                if (k != GLFW.GLFW_KEY_ESCAPE) { key = k; com.meuclient.Config.markDirty(); }
                binding = false;
                keyHeld = true; // a tecla recem-mapeada nao conta como aperto
                return;
            }
        }
    }

    @Override
    public void onDisable() {
        if (returnTimer > 0 && originalSlot >= 0) selectSlot(originalSlot);
        returnTimer = 0;
    }

    @Override
    public void onTick() {
        // devolve o slot original depois do tempo de espera
        if (returnTimer > 0 && --returnTimer == 0 && originalSlot >= 0) {
            selectSlot(originalSlot);
        }

        boolean down = key >= 0 && !binding && mc.currentScreen == null
                && GLFW.glfwGetKey(mc.getWindow().getHandle(), key) == GLFW.GLFW_PRESS;
        boolean pressed = down && !keyHeld; // um aperto = uma lancada
        keyHeld = down;
        if (!pressed) return;

        // alvo e opcional: com jogador perto, ataca ele; sem alvo, lanca para onde voce olha
        PlayerEntity target = Combat.nearestPlayer(mc, 4.5, true);
        int spear = findSpear();
        if (spear == -1) return;

        // guarda o slot original so no primeiro aperto da sequencia
        boolean alreadyParked = returnTimer > 0;
        if (!alreadyParked) originalSlot = mc.player.getInventory().getSelectedSlot();
        int park = alreadyParked ? mc.player.getInventory().getSelectedSlot() : findEmptySlot();

        // tudo no mesmo tick: mao vazia -> lanca -> ataque -> mao vazia
        if (park != -1) selectSlot(park);
        selectSlot(spear);
        if (target != null) {
            Combat.silentAttack(mc, target);
        } else {
            // sem alvo: usa o clique de ataque do proprio jogo (a lancada)
            mc.attackCooldown = 0; // ignora o atraso de 10 ticks depois de "bater no ar"
            mc.doAttack();
        }
        selectSlot(park != -1 ? park : originalSlot);

        returnTimer = park != -1 ? RETURN_DELAY_TICKS : 0;
    }

    private void selectSlot(int slot) {
        mc.player.getInventory().setSelectedSlot(slot);
        if (mc.getNetworkHandler() != null) {
            mc.getNetworkHandler().sendPacket(new UpdateSelectedSlotC2SPacket(slot));
        }
    }

    private int findEmptySlot() {
        for (int i = 0; i < 9; i++) {
            if (mc.player.getInventory().getStack(i).isEmpty()) return i;
        }
        return -1;
    }

    /** Prefere lanca com Lunge; se nao houver, usa qualquer lanca da hotbar. */
    private int findSpear() {
        int any = -1;
        for (int i = 0; i < 9; i++) {
            var stack = mc.player.getInventory().getStack(i);
            if (stack.isEmpty()) continue;
            if (!Registries.ITEM.getId(stack.getItem()).getPath().endsWith("_spear")) continue;
            boolean lunge = stack.getEnchantments().getEnchantments().stream()
                    .anyMatch(e -> e.getIdAsString().equals("minecraft:lunge"));
            if (lunge) return i;
            if (any == -1) any = i;
        }
        return any;
    }
}
