package com.meuclient.modules;

import com.meuclient.Category;
import com.meuclient.Module;

/**
 * Cores: no menu, clicar abre um painel com as cores para escolher
 * (fundo, cor de opcao ativada e cabecalho). Nao liga nem desliga nada.
 */
public class Cores extends Module {
    public Cores() { super("Cores", Category.MISC); }

    @Override
    public boolean isSettings() { return true; }
}
